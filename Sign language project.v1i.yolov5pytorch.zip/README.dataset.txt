# Sign language project > 2024-12-27 1:38pm
https://universe.roboflow.com/yolo-custom-training/sign-language-project-9hgdy

Provided by a Roboflow user
License: CC BY 4.0

